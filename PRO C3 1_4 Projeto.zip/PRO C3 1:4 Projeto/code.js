var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["05537129-9f99-4e55-868c-e541c5a48cd9"],"propsByKey":{"05537129-9f99-4e55-868c-e541c5a48cd9":{"name":"a","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"JxKcknFmuTHi_OXcTEMBiDdZJlyXN1T4","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/05537129-9f99-4e55-868c-e541c5a48cd9.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//criando a jogadora Sofia
var Sofia = createSprite(50, 50, 20, 20); 

//criando as paredes do labirinto (parede1 - parede2)
  var wall1 = createSprite(115, 0, 20, 175) ;
  var wall2 = createSprite(250, 400, 175, 20) ;
  var wall3 = createSprite(150, 200, 175, 20) ;
  var wall4 = createSprite(240, 150, 20, 175) ;
  var wall5 = createSprite(400, 90, 175, 20) ;
  var wall6 = createSprite(250, 129, 175, 20) ;
  var wall7 = createSprite(400, 165, 175, 20) ;
  var wall8 = createSprite(250, 205, 175, 20) ;
  var wall9 = createSprite(60, 280, 20, 175) ;
  var wall10 = createSprite(280, 380, 20, 175) ;
  var wall11 = createSprite(320, 280, 175, 20) ;
  var wall12 = createSprite(130, 400, 20, 175) ;
  var wall13 = createSprite(100, 250, 175, 20) ;
  var wall14 = createSprite(180, 250, 20, 175) ;
  var wall15 = createSprite(155, 115, 20, 175) ;
  var wall16 = createSprite(135, 37, 20, 20) ;
  var wall17 = createSprite(0, 115, 175, 20) ;
  var wallsuper = createSprite(135, 47, 20, 20) ;
  wall16.shapeColor="Red";
//cria a taça
var cup = createSprite(348, 348, 20, 20)
cup.shapeColor="yellow"
  
function draw() {
 //mudando a cor do plano de fundo para rosa
 background("pink");
 if (keyDown("up")) {
  Sofia.y = Sofia.y-5; 
 }
 if (keyDown("down")) {
   Sofia.y = Sofia.y+5;
 }
 if (keyDown("left")) {
   Sofia.x = Sofia.x-5
 }
 if (keyDown("RIGHT")) {
   Sofia.x = Sofia.x+5
 }
 if (Sofia.isTouching(wall16)) {
   Sofia.x=348
   Sofia.y=348
 }
 
 
  drawSprites()
 createEdgeSprites() 
Sofia.collide(wall1);
Sofia.collide(wall2);
Sofia.collide(wall3);
Sofia.collide(wall4);
Sofia.collide(wall5);
Sofia.collide(wall6);
Sofia.collide(wall7);
Sofia.collide(wall8);
Sofia.collide(wall9);
Sofia.collide(wall10);
Sofia.collide(wall11);
Sofia.collide(wall12);
Sofia.collide(wall13);
Sofia.collide(wall14);
Sofia.collide(wall15);
Sofia.collide(wall16);
Sofia.collide(wall17);
Sofia.collide(topEdge);
Sofia.collide(rightEdge);
Sofia.collide(leftEdge);
Sofia.collide(bottomEdge);
Sofia.collide(wallsuper);
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
